"""
excel_analyzer
==============
Librería para detectar y consultar tablas en archivos Excel desordenados
con merged cells, filas/columnas vacías y bloques de datos no contiguos.

MÓDULOS
=======
    _core           Motor de detección: SheetScanner, TableAnalyzer, API base.
    query_engine    Motor de consulta: excel_query(), sinónimos, fuzzy matching.
    table_builder   Motor de construcción: excel_build_table(), pivots analíticos.

API RÁPIDA
==========

    # Detección básica
    from excel_analyzer import detectar_tabla, detectar_todas_las_tablas
    tabla  = detectar_tabla("archivo.xlsx", "Hoja1")
    tablas = detectar_todas_las_tablas("archivo.xlsx", "Hoja1")

    # Extracción
    from excel_analyzer import extraer_fila, extraer_columna, crear_tabla
    extraer_fila(tabla, "AUM")
    extraer_columna(tabla, "ene-26")

    # Query engine — busca en todas las hojas automáticamente
    from excel_analyzer import excel_query
    df = excel_query("archivo.xlsx", metric="AUM")
    df = excel_query("archivo.xlsx", metric="assets")           # sinónimo
    df = excel_query("archivo.xlsx", metric="AUM",
                     where="Manager == 'First Trust'")          # filtro
    df = excel_query("archivo.xlsx", metric="AUM",
                     sheet=2, table=1)                          # hoja específica
    df = excel_query("archivo.xlsx", metric="AUM",
                     mode="merge")                              # todas las hojas

    # Table builder — tablas analíticas con pivot
    from excel_analyzer import excel_build_table
    df = excel_build_table(
        "archivo.xlsx", sheet=2, table=1,
        metrics=["AUM", "ROA"],
        columns=["ene-24", "feb-24", "mar-24"]
    )
    #             AUM                    ROA
    #          ene-24 feb-24 mar-24   ene-24 feb-24 mar-24
    # Manager
    # First Trust  …    …    …          …      …      …

    # Exploración
    from excel_analyzer import describir_tablas, buscar_tabla, tabla_mas_grande
    describir_tablas(tablas)
    tabla = buscar_tabla(tablas, "AUM")
    tabla = tabla_mas_grande(tablas)
"""

# ── Motor de detección (núcleo) ───────────────────────────────────────────────
from .core import (
    # Clases internas
    WorkbookLoader,
    SheetScanner,
    RegionDetector,
    TableParser,
    TableAnalyzer,
    TableRegion,
    # API de detección
    detectar_tabla,
    detectar_todas_las_tablas,
    # API de extracción
    extraer_fila,
    extraer_columna,
    crear_tabla,
    replicar_tabla,
    # Utilidades heredadas (compatibilidad v3)
    detectar_fechas,
    expandir_merged_cells,
)

# ── Motor de consulta (query engine) ─────────────────────────────────────────
from .query_engine import (
    # Función principal
    excel_query,
    # Utilidades de exploración
    buscar_tabla,
    tabla_mas_grande,
    describir_tablas,
    # Motor semántico (accesible para extensión y tests)
    _find_best_metric,
    _get_synonym_candidates,
    _similarity,
    _normalize_text,
)

# ── Motor de construcción de tablas ──────────────────────────────────────────
from .table_builder import (
    excel_build_table,
)

__all__ = [
    # Clases
    "WorkbookLoader",
    "SheetScanner",
    "RegionDetector",
    "TableParser",
    "TableAnalyzer",
    "TableRegion",
    # Detección
    "detectar_tabla",
    "detectar_todas_las_tablas",
    # Extracción
    "extraer_fila",
    "extraer_columna",
    "crear_tabla",
    "replicar_tabla",
    # Utilidades heredadas
    "detectar_fechas",
    "expandir_merged_cells",
    # Query engine
    "excel_query",
    "buscar_tabla",
    "tabla_mas_grande",
    "describir_tablas",
    # Semántico (para extensión / tests)
    "_find_best_metric",
    "_get_synonym_candidates",
    "_similarity",
    "_normalize_text",
    # Table builder
    "excel_build_table",
]