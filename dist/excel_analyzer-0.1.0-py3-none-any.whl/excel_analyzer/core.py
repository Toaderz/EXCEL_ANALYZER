"""
excel_analyzer.py  v6
=====================
Librería para detectar y extraer tablas de archivos Excel desordenados
con merged cells, filas/columnas vacías y bloques de datos no contiguos.

ARQUITECTURA
============

    WorkbookLoader        — IO puro: abre el workbook, entrega (ws, merged_ranges)
         ↓
    SheetScanner          — matrix numpy + masks cacheadas (una sola lectura del disco)
         ↓
    RegionDetector        — detección de regiones O(n) puro numpy (np.diff, sin sets)
         ↓
    TableParser           — convierte regiones en TableRegion (dataclass tipada)
         ↓
    TableAnalyzer         — orquesta, cachea resultados, expone API interna
         ↓
    API pública           — detectar_tabla(), extraer_columna(), etc. (compatible v3+)

HISTORIAL DE CAMBIOS
====================

  v3 → v4
    • Un solo escaneo de la hoja (ws.values → numpy matrix)
    • Acceso O(1) a celdas vía matrix en lugar de ws.cell()
    • Merged cells expandidas directamente en la matrix
    • WorkbookLoader separado del scanner (IO desacoplado)
    • RegionDetector: _agrupar con np.diff en lugar de set+sort (15x más rápido)
    • RegionDetector.detectar: ndarray de np.where directamente (sin conversión a set,
      elimina 33x overhead)
    • Detección de orientación con umbral absoluto MIN_DATES_FOR_ORIENTATION
    • TableRegion como @dataclass tipada en lugar de dict genérico
    • score = n_filas × n_fechas en lugar de solo n_fechas
    • TableAnalyzer.from_scanner() para reutilizar scanner sin reabrir archivo
    • data: pd.DataFrame | None para lazy parsing futuro
    • ws.iter_rows(values_only=True) en lugar de ws.values (API documentada y explícita)

  v4 → v5  (sin cambio de comportamiento visible, solo performance interno)
    • _build_meaningful_mask y _build_datetime_mask: eliminan np.vectorize sobre
      toda la matrix. Aplican la operación solo sobre celdas no-None (≈25% del total):
        1. (mat != None) → C-level sobre todo el array (rápido)
        2. frompyfunc     → solo sobre el subconjunto no-None
      Resultado medido: 1.3–1.4x más rápido en hojas de 5000×100.

  v5 → v6  (sin cambio de comportamiento visible, solo performance interno)
    • _build_masks(): fusiona las dos máscaras (meaningful + datetime) en UN SOLO
      recorrido de los valores no-None:
        1. np.frompyfunc(type, 1, 1)  → obtiene tipos en batch (una sola llamada)
        2. is_str  = (types == str)   → selecciona strings sin bucle Python
        3. np.char.strip / startswith → operaciones C-level solo sobre strings
        4. is_dt   = (types == datetime.datetime) → máscara datetime directo
      Resultado medido: 2.0x más rápido que v5 en hojas de 5000×100
      (43 ms vs 88 ms para 500k celdas no-None).

NOTAS TÉCNICAS
==============

  • np.frompyfunc(type, 1, 1): aunque frompyfunc sigue siendo un loop Python,
    llamar type() es mucho más barato que str() (no construye un nuevo objeto).
    Extraer los tipos en batch permite derivar AMBAS máscaras con un solo recorrido.

  • np.char.strip / np.char.startswith: operan sobre arrays de dtype str (no object),
    ejecutando las comparaciones en C. Solo se aplican a la fracción de celdas
    que son strings (≈17% en hojas financieras típicas).

  • dtype=object es inevitable para arrays con tipos mixtos (str, datetime, float, None).
    Para hojas normales (5000×100) ≈ 3.8 MB de memoria — aceptable.

  • _MESES_ES vs calendar.month_abbr: calendar da nombres en inglés ('Jan', 'Feb'…).
    Para reportes financieros en español se requiere la lista explícita.
    Rendimiento medido: 0.6 μs vs 2.7 μs por llamada — _MESES_ES también es más rápido.

  • score = n_filas × n_fechas es correcto en todos los casos:
      - fila_header is None → clave_valor → n_fechas=0 → score=0 (correcto)
      - fila_header == fila_inicio → n_filas = fila_fin - fila_header (datos puros)
      - max(0, ...) evita scores negativos si la región es solo el header

  • _bbox_cols no requiere caché: con numpy la operación tarda <0.01ms por región.
    El overhead de gestionar la caché superaría el beneficio.
"""

from __future__ import annotations

import datetime
import re
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Literal

import numpy as np
import openpyxl
import pandas as pd
from openpyxl.utils import get_column_letter


# ══════════════════════════════════════════════════════════════════════════════
# TIPOS Y CONSTANTES
# ══════════════════════════════════════════════════════════════════════════════

TableType   = Literal["manager_metrica", "solo_metrica", "clave_valor"]  # extended below
Orientation = Literal["column", "row", "ambiguous"]

# Nombres de meses en español para etiquetas de fecha (ej. "ene-24").
# Se usa lista explícita en lugar de calendar.month_abbr porque:
#   1. calendar da nombres en inglés ('Jan', 'Feb'…)
#   2. Acceso por índice en lista es 0.6 μs vs 2.7 μs con calendar
_MESES_ES = ["ene","feb","mar","abr","may","jun","jul","ago","sep","oct","nov","dic"]

# Mínimo de fechas en una fila/columna para confiar en la detección de orientación.
# Con menos de 3 fechas el ratio es demasiado sensible a ruido.
_MIN_DATES_FOR_ORIENTATION = 3

# Regex compilada para detectar fechas almacenadas como string en Excel.
# Muchos archivos exportan las fechas como texto en lugar de datetime.datetime.
# Patrones soportados:
#   2024-01   → año-mes ISO
#   01/2024   → mes/año
#   ene-24    → abreviatura española (3 letras + 2 dígitos de año)
#   Jan-24    → abreviatura inglesa  (idem, case-insensitive vía .lower())
# El regex se aplica DESPUÉS de convertir a minúsculas y strip.
_DATE_STRING_RE = re.compile(
    r"^\d{4}-\d{2}$"        # 2024-01
    r"|^\d{2}/\d{4}$"       # 01/2024
    r"|^[a-z]{3}-\d{2}$"    # ene-24 / jan-24 (lowercased before match)
)
_looks_like_date_vec = np.frompyfunc(
    lambda s: bool(_DATE_STRING_RE.match(s.strip().lower())), 1, 1
)

# Tabla tipo genérico agregado para fallback universal
TableType   = Literal["manager_metrica", "solo_metrica", "clave_valor", "tabla_generica", "tabla_rotada", "tabla_cruzada"]


# ══════════════════════════════════════════════════════════════════════════════
# 1. WorkbookLoader  — IO puro, separado del scanner
# ══════════════════════════════════════════════════════════════════════════════

class WorkbookLoader:
    """
    Responsabilidad única: abrir un .xlsx y entregar (ws, merged_ranges).

    Separar el IO del scanner permite:
      - Testear SheetScanner con datos sintéticos sin tocar disco.
      - Reutilizar un scanner construido para analizar el mismo archivo
        varias veces sin reabrirlo (TableAnalyzer.from_scanner).
      - Cambiar el backend de lectura (xlrd, calamine…) sin tocar el pipeline.
    """

    @staticmethod
    def load(archivo: str | Path, hoja: str) -> tuple[Any, list[Any]]:
        """
        Abre el archivo y devuelve (ws, merged_ranges).

        Args:
            archivo: Ruta al .xlsx.
            hoja   : Nombre de la hoja.

        Returns:
            (worksheet, list[MergedCellRange])

        Raises:
            FileNotFoundError si el archivo no existe.
            ValueError si la hoja no existe en el workbook.
        """
        path = Path(archivo)
        if not path.exists():
            raise FileNotFoundError(f"Archivo no encontrado: {path}")
        wb = openpyxl.load_workbook(str(path), data_only=True)
        if hoja not in wb.sheetnames:
            raise ValueError(
                f"Hoja '{hoja}' no existe. Disponibles: {wb.sheetnames}"
            )
        ws            = wb[hoja]
        merged_ranges = list(ws.merged_cells.ranges)
        return ws, merged_ranges


# ══════════════════════════════════════════════════════════════════════════════
# 2. SheetScanner  — matrix numpy + masks cacheadas
# ══════════════════════════════════════════════════════════════════════════════

class SheetScanner:
    """
    Carga el worksheet en memoria UNA sola vez como numpy object array (base-0)
    y expone todas las operaciones de consulta como accesos O(1) o vectorizados.

    Construcción:
        ws, merged_ranges = WorkbookLoader.load(archivo, hoja)
        scanner = SheetScanner(ws, merged_ranges)

    Acceso O(1):
        scanner[r, c]      — base-0
        scanner.get1(r, c) — base-1 (estilo Excel)

    Masks precalculadas (calculadas UNA vez en __init__, luego O(1)):
        scanner._mask_meaningful  — bool array, True = celda con dato válido
        scanner._mask_datetime    — bool array, True = celda con datetime
        scanner.row_density       — int array (nrows,), n celdas con datos por fila
        scanner.col_density       — int array (ncols,), n celdas con datos por columna
        scanner.orientation       — "column" | "row" | "ambiguous"
    """

    def __init__(self, ws: Any, merged_ranges: list[Any]) -> None:
        self.hoja  = getattr(ws, "title", "")
        self.nrows = ws.max_row
        self.ncols = ws.max_column

        # ── Cargar en numpy array (una sola iteración de la hoja) ─────────
        # ws.iter_rows(values_only=True) es la API documentada y explícita
        # de openpyxl y garantiza filas rectangulares (padding con None).
        self._mat: np.ndarray = np.empty((self.nrows, self.ncols), dtype=object)
        for ri, row in enumerate(ws.iter_rows(values_only=True)):
            for ci, v in enumerate(row):
                self._mat[ri, ci] = v

        # ── Expandir merged cells directamente en la matrix ───────────────
        # Slicing 2D de numpy sobrescribe el valor en toda la región del merge.
        # Evita el dict auxiliar {(r,c): val} de versiones anteriores.
        for rng in merged_ranges:
            val = self._mat[rng.min_row - 1, rng.min_col - 1]
            self._mat[
                rng.min_row - 1 : rng.max_row,
                rng.min_col - 1 : rng.max_col,
            ] = val

        # ── Construir ambas masks en UN solo recorrido de celdas ──────────
        self._mask_meaningful, self._mask_datetime = self._build_masks()

        # Densidades: sum() de bool array es C-level sobre numpy
        self.row_density: np.ndarray = self._mask_meaningful.sum(axis=1)
        self.col_density: np.ndarray = self._mask_meaningful.sum(axis=0)

        # Orientación dominante de las fechas
        self.orientation: Orientation = self._detect_orientation()

    # ── Acceso a celdas ────────────────────────────────────────────────────

    def __getitem__(self, idx: tuple[int, int]) -> Any:
        """scanner[r, c] — índice base-0."""
        return self._mat[idx]

    def get(self, r: int, c: int) -> Any:
        """Valor de (r, c), base-0."""
        return self._mat[r, c]

    def get1(self, r: int, c: int) -> Any:
        """Valor de (r, c), base-1 (estilo Excel)."""
        return self._mat[r - 1, c - 1]

    def slice1(self, r0: int, r1: int, c0: int, c1: int) -> np.ndarray:
        """Sub-matrix base-1 [r0..r1]×[c0..c1] (inclusive, estilo Excel)."""
        return self._mat[r0 - 1 : r1, c0 - 1 : c1]

    # ── Masks de sub-rango ────────────────────────────────────────────────

    def meaningful_mask(
        self,
        r0: int = 0, r1: int | None = None,
        c0: int = 0, c1: int | None = None,
    ) -> np.ndarray:
        """Sub-mask de celdas con dato válido, rango base-0 [r0:r1, c0:c1]."""
        return self._mask_meaningful[
            r0 : (r1 or self.nrows),
            c0 : (c1 or self.ncols),
        ]

    def date_mask(
        self,
        r0: int = 0, r1: int | None = None,
        c0: int = 0, c1: int | None = None,
    ) -> np.ndarray:
        """Sub-mask de celdas con datetime, rango base-0 [r0:r1, c0:c1]."""
        return self._mask_datetime[
            r0 : (r1 or self.nrows),
            c0 : (c1 or self.ncols),
        ]

    # ── Core: construir ambas masks en un recorrido ───────────────────────

    def _build_masks(self) -> tuple[np.ndarray, np.ndarray]:
        """
        Construye _mask_meaningful y _mask_datetime en un único recorrido
        de los valores no-None.

        Estrategia (medida en benchmark, 5000×100 = 500k celdas):

          Paso 1: (mat != None)
            Comparación C-level sobre todo el array. Rápida e inevitable.
            Identifica el ≈25% de celdas que tienen algún valor.

          Paso 2: np.frompyfunc(type, 1, 1)(vals)
            Obtiene el tipo Python de CADA celda no-None en UN solo recorrido.
            Llamar type() es mucho más barato que str() porque no construye
            un nuevo objeto — solo devuelve el puntero de tipo ya existente.

          Paso 3a: meaningful  
            - Celdas no-string (datetime, int, float…) → siempre True
            - Strings: np.char.strip + np.char.startswith (C-level, ≈17% del total)

          Paso 3b: datetime
            - (types == datetime.datetime) → comparación de punteros, O(n) C-level

          Resultado medido: 2.0x más rápido que v5 para hojas de 5000×100
          (43 ms vs 88 ms al construir ambas masks).
        """
        # ── Paso 1: celdas no-None ────────────────────────────────────────
        not_none = self._mat != None    # noqa: E711  C-level
        pos      = np.where(not_none)
        vals     = self._mat[pos]

        mask_m  = np.zeros((self.nrows, self.ncols), dtype=bool)
        mask_dt = np.zeros((self.nrows, self.ncols), dtype=bool)

        if len(vals) == 0:
            return mask_m, mask_dt

        # ── Paso 2: tipos en batch (un solo recorrido) ───────────────────
        types = np.frompyfunc(type, 1, 1)(vals)   # object array of Python types

        # ── Paso 3a: meaningful mask ──────────────────────────────────────
        is_str = (types == str)                    # selección de strings

        # Por defecto toda celda no-None es meaningful (datetime, int, float…)
        meaningful = np.ones(len(vals), dtype=bool)

        if is_str.any():
            # np.char requiere array de dtype str (no object)
            # Solo procesamos el subconjunto de strings (≈17% típico)
            str_vals    = vals[is_str].astype(str)
            str_stripped = np.char.strip(str_vals)
            bad          = (str_stripped == "") | np.char.startswith(str_stripped, "#")
            meaningful[is_str] = ~bad

        # ── Paso 3b: datetime mask ────────────────────────────────────────
        # Incluye celdas datetime.datetime Y strings con aspecto de fecha
        # (ej. "ene-24", "Jan-24", "2024-01", "03/2024").
        # Esto permite detectar tablas donde Excel guardó las fechas como texto.
        is_dt = (types == datetime.datetime)       # puntero de tipo, sin isinstance

        if is_str.any():
            # _looks_like_date_vec ya opera sobre str_stripped (dtype=str)
            # Solo se necesita si hay strings — condición del bloque exterior
            str_stripped_for_dt = np.char.strip(vals[is_str].astype(str))
            is_dt_str            = _looks_like_date_vec(str_stripped_for_dt).astype(bool)
            is_dt                = is_dt.copy()
            is_dt[is_str]        = is_dt_str

        # ── Escribir en arrays resultado ──────────────────────────────────
        mask_m[pos]  = meaningful
        mask_dt[pos] = is_dt.astype(bool)

        return mask_m, mask_dt

    # ── Orientación ───────────────────────────────────────────────────────

    def _detect_orientation(self) -> Orientation:
        """
        Determina si las fechas son encabezados de columna ("column") o
        etiquetas de fila ("row").

        Lógica:
          - Si ninguna dimensión acumula ≥ _MIN_DATES_FOR_ORIENTATION fechas
            en una sola fila/columna → "ambiguous" (evita falsos positivos con
            hojas sin fechas o con muy pocas).
          - ratio = max_fechas_en_alguna_fila / max_fechas_en_alguna_col
            ratio ≥ 1.5 → "column"
            ratio ≤ 0.67 → "row"
            en medio → "ambiguous"
        """
        row_dates = int(self._mask_datetime.sum(axis=1).max())
        col_dates = int(self._mask_datetime.sum(axis=0).max())

        if max(row_dates, col_dates) < _MIN_DATES_FOR_ORIENTATION:
            return "ambiguous"

        ratio = row_dates / max(col_dates, 1)
        if ratio >= 1.5:
            return "column"
        if ratio <= 0.67:
            return "row"
        return "ambiguous"

    # ── Utilidades ────────────────────────────────────────────────────────

    @staticmethod
    def _is_cell_meaningful(v: Any) -> bool:
        """
        True si v tiene un dato válido (no None, no vacío, no error Excel).
        Llamado en el loop de parseo de filas, no en la construcción de masks.
        Usa type() en lugar de isinstance() para evitar la herencia y ser
        consistente con _build_masks.
        """
        if v is None:
            return False
        t = type(v)
        if t is str:
            s = v.strip()
            return bool(s) and s[0] != "#"
        return True   # datetime, int, float, bool → siempre significativo

    @staticmethod
    def fmt_fecha(v: Any) -> str:
        """
        Convierte un datetime → 'mmm-aa' (ej. 'ene-24').
        Otro tipo → str(v).strip().
        """
        if isinstance(v, datetime.datetime):
            return f"{_MESES_ES[v.month - 1]}-{str(v.year)[2:]}"
        return str(v).strip() if v is not None else ""


# ══════════════════════════════════════════════════════════════════════════════
# 3. TableRegion  — dataclass tipada para una región detectada
# ══════════════════════════════════════════════════════════════════════════════

@dataclass
class TableRegion:
    """
    Representa una sub-tabla detectada en la hoja.
    Todos los índices son base-1 (estilo Excel) en la API pública.

    Campos:
        id          : Índice de tabla (1, 2, …)
        tipo        : "manager_metrica" | "solo_metrica" | "clave_valor"
        orientacion : "column" | "row" | "ambiguous"
        fila_inicio : Primera fila del bloque, incluye header (base-1)
        fila_fin    : Última fila del bloque (base-1)
        col_inicio  : Primera columna del bloque (base-1)
        col_fin     : Última columna del bloque (base-1)
        fila_header : Fila de encabezados de fecha (base-1), None si clave_valor
        col_manager : Columna de managers (base-1), None si no aplica
        col_metrica : Columna de métricas (base-1), None si no aplica
        col_headers : {col_base1: label_fecha, …}
        titulo      : Título del bloque (si existe), None en otro caso
        data        : DataFrame con MultiIndex, o None si lazy (futuro)
    """

    id:          int
    tipo:        TableType
    orientacion: Orientation
    fila_inicio: int
    fila_fin:    int
    col_inicio:  int
    col_fin:     int
    fila_header: int | None
    col_manager: int | None
    col_metrica: int | None
    col_headers: dict[int, str]
    titulo:      str | None
    data:        pd.DataFrame | None = field(repr=False)

    @property
    def score(self) -> float:
        """
        Puntuación para selección de tabla principal:
            score = n_filas_datos × n_columnas_fecha

        n_filas_datos = fila_fin - fila_header  (excluye la fila de header).
        Si fila_header es None (clave_valor) se usa fila_inicio, pero en ese
        caso n_columnas_fecha = 0 así que score = 0 de todas formas.
        max(0, …) evita scores negativos en regiones degeneradas (solo header).
        """
        ref     = self.fila_header if self.fila_header is not None else self.fila_inicio
        n_filas = max(0, self.fila_fin - ref)
        n_fechas = len(self.col_headers)

        # Densidad = celdas de datos esperadas / celdas totales del bloque.
        # Penaliza tablas grandes con mucho espacio vacío que podrían ganar
        # solo por tamaño físico.
        total     = (self.fila_fin - self.fila_inicio + 1) * (self.col_fin - self.col_inicio + 1)
        meaningful = n_filas * max(n_fechas, 1)
        densidad  = meaningful / max(total, 1)

        return float(n_filas * n_fechas * densidad)

    def as_dict(self) -> dict[str, Any]:
        """Devuelve un dict compatible con la API pública v3/v4/v5."""
        return {
            "id":          self.id,
            "tipo":        self.tipo,
            "orientacion": self.orientacion,
            "fila_inicio": self.fila_inicio,
            "fila_fin":    self.fila_fin,
            "col_inicio":  self.col_inicio,
            "col_fin":     self.col_fin,
            "fila_header": self.fila_header,
            "col_manager": self.col_manager,
            "col_metrica": self.col_metrica,
            "col_headers": self.col_headers,
            "titulo":      self.titulo,
            "score":       self.score,
            "data":        self.data,
        }


# ══════════════════════════════════════════════════════════════════════════════
# 4. RegionDetector  — O(n) puro numpy, sin sets Python
# ══════════════════════════════════════════════════════════════════════════════

class RegionDetector:
    """
    Detecta las regiones rectangulares de la hoja que probablemente
    contienen tablas de datos.

    Todo el trabajo se hace sobre las masks cacheadas del scanner.
    No hay llamadas a openpyxl después de la construcción del scanner.

    Algoritmo:
      1. Filas activas: row_density >= umbral (numpy, ya calculado)
      2. Agrupar en bandas: np.diff detecta saltos en O(n) sin sets Python
      3. Para bandas con fechas: subdividir usando columnas ancla (cols 0 y 1
         del bloque), mismo algoritmo np.diff

    Complejidad: O(n) donde n = número de filas de la hoja.
    """

    def __init__(
        self,
        scanner: SheetScanner,
        umbral_densidad: int = 2,
        gap_max_externo: int = 2,
        gap_max_interno: int = 1,
    ) -> None:
        self.sc          = scanner
        self.umbral      = umbral_densidad
        self.gap_externo = gap_max_externo
        self.gap_interno = gap_max_interno

    def detectar(self) -> list[tuple[int, int]]:
        """
        Devuelve lista de (r_ini, r_fin) en base-0 para cada sub-región detectada.
        Las regiones están ordenadas y sin duplicados.
        """
        # row_density ya calculada por scanner — sin escaneo adicional
        activas = np.where(self.sc.row_density >= self.umbral)[0]
        if len(activas) == 0:
            return []

        bandas = self._agrupar(activas, self.gap_externo)
        subregiones: list[tuple[int, int]] = []

        for r0, r1 in bandas:
            n_fechas = int(self.sc._mask_datetime[r0 : r1 + 1, :].sum())

            if n_fechas < 2:
                subregiones.append((r0, r1))
                continue

            # Subdividir por densidad en las columnas ancla del bloque
            c0, _ = self._bbox_cols(r0, r1)
            ancla1 = c0
            ancla2 = min(c0 + 1, self.sc.ncols - 1)

            # OR de las dos columnas ancla → filas localmente activas en el bloque
            sub_mask      = (
                self.sc._mask_meaningful[r0 : r1 + 1, ancla1]
                | self.sc._mask_meaningful[r0 : r1 + 1, ancla2]
            )
            local_activas = np.where(sub_mask)[0] + r0   # convertir a índice global
            sub_grupos    = self._agrupar(local_activas, self.gap_interno)

            if len(sub_grupos) <= 1:
                subregiones.append((r0, r1))
            else:
                subregiones.extend(sub_grupos)

        # Deduplicar preservando orden (las subregiones ya vienen ordenadas)
        seen:   set[tuple[int, int]] = set()
        result: list[tuple[int, int]] = []
        for sr in subregiones:
            if sr not in seen:
                seen.add(sr)
                result.append(sr)
        return result

    def _bbox_cols(self, r0: int, r1: int) -> tuple[int, int]:
        """Columna mínima y máxima con datos en [r0, r1] (base-0, inclusivo)."""
        sub  = self.sc._mask_meaningful[r0 : r1 + 1, :]
        cols = np.where(sub.any(axis=0))[0]
        return (int(cols[0]), int(cols[-1])) if len(cols) > 0 else (0, 0)

    @staticmethod
    def _agrupar(activas: np.ndarray, gap_max: int) -> list[tuple[int, int]]:
        """
        Agrupa un ndarray ordenado de índices de filas en intervalos (ini, fin)
        donde cada grupo tiene huecos internos ≤ gap_max.

        Implementación O(n) con np.diff: no requiere sets ni sort en Python.
        Medido 15x más rápido que la versión con set+sort+loop (v3).

        Args:
            activas : ndarray 1D ya ordenado de índices de filas activas.
            gap_max : Máximo de filas vacías dentro de un mismo grupo.

        Returns:
            Lista de (ini, fin) como ints Python.
        """
        if len(activas) == 0:
            return []

        breaks = np.where(np.diff(activas) > gap_max + 1)[0]
        starts = np.concatenate([[activas[0]],      activas[breaks + 1]])
        ends   = np.concatenate([activas[breaks],   [activas[-1]]])

        return [(int(s), int(e)) for s, e in zip(starts, ends)]


# ══════════════════════════════════════════════════════════════════════════════
# 5. TableParser  — convierte un rango (r0, r1) en TableRegion
# ══════════════════════════════════════════════════════════════════════════════

class TableParser:
    """
    Convierte un rango de filas (r0, r1) base-0 en un TableRegion tipado.

    Todo acceso a celdas va contra scanner._mat (numpy, O(1)).
    Ninguna llamada a openpyxl después de la construcción del scanner.
    """

    def __init__(self, scanner: SheetScanner) -> None:
        self.sc = scanner

    def parse(self, r0: int, r1: int, region_id: int) -> TableRegion | None:
        """
        Determina el tipo del rango y lo parsea.

        Prioridad:
          1. ≥ 2 fechas en alguna fila  → tabla con fechas (manager_metrica / solo_metrica).
          2. Sin fechas, clave-valor válida → clave_valor.
          3. Fallback universal           → tabla_generica.
        """
        c0, c1        = self._bbox_cols(r0, r1)
        fila_h0, n_dt = self._fila_con_mas_fechas(r0, r1, c0, c1)

        if n_dt >= 2:
            return self._parse_con_fechas(r0, r1, c0, c1, fila_h0, region_id)

        kv = self._parse_clave_valor(r0, r1, c0, c1, region_id)
        if kv is not None:
            return kv

        # Fallback: cualquier bloque de datos sin fechas ni clave-valor clara
        return self._parse_generic_table(r0, r1, c0, c1, region_id)

    # ── Parseo con fechas ──────────────────────────────────────────────────

    def _parse_con_fechas(
        self,
        r0: int, r1: int, c0: int, c1: int,
        fila_h0: int, region_id: int,
    ) -> TableRegion | None:
        """
        Parsea una región con fila de encabezados de fecha.

        Detecta automáticamente:
          - Columnas de etiqueta: las que están a la izquierda de la primera
            fecha en la fila de header Y tienen datos en filas de datos.
          - Si hay ≥ 2 columnas de etiqueta: primera = manager, segunda = métrica.
          - Si hay 1 columna de etiqueta: solo métrica.
        """
        # Columnas de fechas en la fila de header (base-1 en el dict)
        col_datos: dict[int, str] = {}
        primera_c = c1 + 1

        for c in range(c0, c1 + 1):
            v = self.sc[fila_h0, c]

            if isinstance(v, datetime.datetime) or (
                isinstance(v, str) and _DATE_STRING_RE.match(v.strip().lower())
            ):
                col_datos[c + 1] = self.sc.fmt_fecha(v)
                primera_c = min(primera_c, c)

        if not col_datos:
            return None

        # Columnas de etiqueta: izquierda de la primera fecha,
        # con al menos un dato en las filas de debajo del header
        col_etiquetas = [
            c for c in range(c0, primera_c)
            if self.sc._mask_meaningful[fila_h0 + 1 : r1 + 1, c].any()
        ]

        col_manager_0 = col_etiquetas[0] if len(col_etiquetas) >= 2 else None
        col_metrica_0 = (
            col_etiquetas[1] if len(col_etiquetas) >= 2
            else (col_etiquetas[0] if col_etiquetas else None)
        )
        if col_metrica_0 is None:
            # Fallback: buscar columnas numéricas a la izquierda de las fechas.
            # Rescata tablas donde los headers son "AUM | ROA | ROI" sin columna
            # de etiqueta de texto (ej. solo números debajo de cada header).
            # Solo se consideran columnas en [c0, primera_c) para no confundir
            # columnas de datos con columnas de etiquetas.
            numeric_cols = []
            for c in range(c0, primera_c):
                col_vals = self.sc._mat[fila_h0 + 1 : r1 + 1, c]
                n_nums = sum(
                    isinstance(v, (int, float)) and not isinstance(v, bool)
                    for v in col_vals
                    if v is not None
                )
                if len(col_vals) > 0 and n_nums >= len(col_vals) * 0.6:
                    numeric_cols.append(c)
            if numeric_cols:
                col_metrica_0 = numeric_cols[0]
            else:
                return None

        # Leer filas de datos (acceso O(1) a scanner._mat)
        data_cols  = sorted(col_datos.keys())     # base-1
        col_labels = [col_datos[c] for c in data_cols]
        registros: list[dict[str, Any]] = []
        manager_actual: str | None = None

        for r in range(fila_h0 + 1, r1 + 1):
            # Propagar manager (merged verticalmente)
            if col_manager_0 is not None:
                vm = self.sc[r, col_manager_0]
                if self.sc._is_cell_meaningful(vm):
                    manager_actual = str(vm).strip()

            vmet = self.sc[r, col_metrica_0]
            if not self.sc._is_cell_meaningful(vmet):
                continue

            fila_d: dict[str, Any] = {"Métrica": str(vmet).strip()}
            if col_manager_0 is not None:
                fila_d["Manager"] = manager_actual

            for c_b1, lbl in zip(data_cols, col_labels):
                v = self.sc[r, c_b1 - 1]    # base-1 → base-0
                fila_d[lbl] = v if self.sc._is_cell_meaningful(v) else None

            registros.append(fila_d)

        if not registros:
            return None

        df  = pd.DataFrame(registros)
        idx = ["Manager", "Métrica"] if "Manager" in df.columns else ["Métrica"]
        df  = df.set_index(idx)

        tipo: TableType = "manager_metrica" if col_manager_0 is not None else "solo_metrica"

        return TableRegion(
            id          = region_id,
            tipo        = tipo,
            orientacion = "column",
            fila_inicio = r0 + 1,
            fila_fin    = r1 + 1,
            col_inicio  = c0 + 1,
            col_fin     = c1 + 1,
            fila_header = fila_h0 + 1,
            col_manager = col_manager_0 + 1 if col_manager_0 is not None else None,
            col_metrica = col_metrica_0 + 1,
            col_headers = col_datos,
            titulo      = None,
            data        = df,
        )

    # ── Parseo clave-valor ─────────────────────────────────────────────────

    def _parse_clave_valor(
        self,
        r0: int, r1: int, c0: int, c1: int, region_id: int,
    ) -> TableRegion | None:
        """
        Parsea una región de 2 columnas: nombre → valor.
        Primera fila con dato en col A y vacía en col B = título del bloque.
        """
        registros: list[dict[str, Any]] = []
        titulo: str | None = None
        c_b = min(c0 + 1, self.sc.ncols - 1)

        for r in range(r0, r1 + 1):
            va = self.sc[r, c0]
            vb = self.sc[r, c_b]
            a_ok = self.sc._is_cell_meaningful(va)
            b_ok = self.sc._is_cell_meaningful(vb)

            if a_ok and not b_ok and titulo is None:
                titulo = str(va).strip()
                continue
            if not a_ok:
                continue
            registros.append({"Nombre": str(va).strip(), "Valor": vb})

        if not registros:
            return None

        df = pd.DataFrame(registros).set_index("Nombre")

        return TableRegion(
            id          = region_id,
            tipo        = "clave_valor",
            orientacion = "ambiguous",
            fila_inicio = r0 + 1,
            fila_fin    = r1 + 1,
            col_inicio  = c0 + 1,
            col_fin     = c1 + 1,
            fila_header = None,
            col_manager = None,
            col_metrica = None,
            col_headers = {},
            titulo      = titulo,
            data        = df,
        )

    # ── Helpers ────────────────────────────────────────────────────────────

    def _bbox_cols(self, r0: int, r1: int) -> tuple[int, int]:
        """Columnas mínima y máxima con datos en [r0, r1] base-0."""
        sub  = self.sc._mask_meaningful[r0 : r1 + 1, :]
        cols = np.where(sub.any(axis=0))[0]
        return (int(cols[0]), int(cols[-1])) if len(cols) > 0 else (0, 0)

    # ── Detección y normalización de tablas no-estándar ──────────────────────

    @staticmethod
    def _is_rotated_table(df: pd.DataFrame) -> bool:
        """
        Detecta si el DataFrame está orientado como 'columna por métrica' y debe transponerse.

        Una tabla rotada tiene su primera FILA como nombres de métricas (strings)
        y el resto de filas como valores numéricos:

            col0  col1
            AUM   ROA      ← primera fila: todos strings
            10    1.2      ← resto: numérico
            20    1.4

        Criterio:
          - Primera fila: ≥ 80 % strings no-vacíos.
          - Filas restantes: ≥ 70 % numérico (o None).
          - Al menos 2 columnas y 2 filas de datos (3 filas totales).

        No aplica a tablas ya parseadas como financieras (tienen index Métrica).
        """
        if df.shape[0] < 3 or df.shape[1] < 2:
            return False

        first_row  = df.iloc[0]
        frs = first_row.map(
            lambda x: isinstance(x, str) and x.strip() != ""
        ).mean()
        if frs < 0.8:
            return False

        data_rows = df.iloc[1:]
        data_num  = data_rows.map(
            lambda x: x is None or (isinstance(x, (int, float)) and not isinstance(x, bool))
        ).mean().mean()
        return bool(data_num >= 0.7)

    @staticmethod
    def _is_cross_table(df: pd.DataFrame) -> bool:
        """
        Detecta si el DataFrame es una tabla cruzada (pivot visual) que debe 'derretirse'.

        Una tabla cruzada tiene métricas en la primera columna y categorías
        (años, trimestres, etc.) como encabezados de las columnas restantes:

            Métrica  Q1    Q2    Q3
            AUM      10    20    30
            ROA      1.2   1.4   1.6

        Criterio:
          - Primera columna: ≥ 80 % strings no-vacíos (nombres de métricas).
          - Columnas restantes: ≥ 70 % numérico (o None).
          - Al menos 2 filas (métricas) y 3 columnas totales (1 label + 2 value).

        Nota: requiere shape[1] >= 3 para distinguirla de una tabla clave-valor
        de 2 columnas, que ya maneja _parse_clave_valor.
        """
        if df.shape[0] < 2 or df.shape[1] < 3:
            return False

        first_col = df.iloc[:, 0].dropna()
        if len(first_col) == 0:
            return False
        fcs = first_col.map(
            lambda x: isinstance(x, str) and x.strip() != ""
        ).mean()
        if fcs < 0.8:
            return False

        other_cols = df.iloc[:, 1:]
        other_num  = other_cols.map(
            lambda x: x is None or (isinstance(x, (int, float)) and not isinstance(x, bool))
        ).mean().mean()
        return bool(other_num >= 0.7)

    @staticmethod
    def _normalize_cross_table(df: pd.DataFrame) -> pd.DataFrame:
        """
        Convierte una tabla cruzada en formato largo (tidy/unpivot).

        Input (wide):
            Métrica  Q1    Q2
            AUM      10    20
            ROA      1.2   1.4

        Output (long):
            Métrica  Header  Valor
            AUM      Q1      10
            ROA      Q1      1.2
            AUM      Q2      20
            ROA      Q2      1.4

        La primera columna se renombra a 'Métrica' si aún no se llama así.
        Las columnas de valores se convierten en una columna 'Header'.
        Los valores se colocan en 'Valor'.
        """
        metric_col = df.columns[0]
        df_long    = df.melt(
            id_vars   = [metric_col],
            var_name  = "Header",
            value_name = "Valor",
        )
        if str(metric_col) != "Métrica":
            df_long.rename(columns={metric_col: "Métrica"}, inplace=True)
        return df_long.reset_index(drop=True)

    def _parse_generic_table(
        self,
        r0: int, r1: int, c0: int, c1: int, region_id: int,
    ) -> TableRegion:
        """
        Fallback universal: convierte cualquier bloque de datos en una tabla genérica.

        Se invoca cuando:
          - La región no tiene suficientes fechas para ser tabla financiera (n_dt < 2).
          - Y _parse_clave_valor no pudo construir una tabla válida.

        Pipeline interno:
          1. Cargar bloque como DataFrame crudo.
          2. Detectar y aplicar header de texto (si la primera fila tiene ≥ 50 % strings).
          3. Detectar tabla rotada (_is_rotated_table) → transponer.
          4. Detectar tabla cruzada (_is_cross_table) → melt a formato largo.

        El tipo resultante refleja la normalización aplicada:
          - Sin transformación: "tabla_generica"
          - Tras transponer:   "tabla_rotada"
          - Tras melt:         "tabla_cruzada"

        Returns:
            TableRegion de tipo "tabla_generica" | "tabla_rotada" | "tabla_cruzada".
            Nunca None.
        """
        mat = self.sc._mat[r0 : r1 + 1, c0 : c1 + 1]
        df  = pd.DataFrame(mat)

        # ── Paso 1: detectar header de texto ─────────────────────────────
        first_row       = df.iloc[0].tolist()
        n_strings       = sum(isinstance(v, str) and v.strip() != "" for v in first_row)
        has_text_header = n_strings >= len(first_row) * 0.5

        if has_text_header:
            df.columns = [
                str(v).strip() if (isinstance(v, str) and v.strip()) else f"col{i}"
                for i, v in enumerate(first_row)
            ]
            df = df.iloc[1:].reset_index(drop=True)
        else:
            df.columns = [f"col{i}" for i in range(df.shape[1])]

        # ── Paso 2: corregir rotación ─────────────────────────────────────
        # Una tabla rotada tiene la primera FILA como nombres de métricas
        # y las demás filas como valores. Se transpone para que las métricas
        # queden en la primera COLUMNA (formato estándar para el paso 3).
        tipo: TableType = "tabla_generica"
        if self._is_rotated_table(df):
            df   = df.T.reset_index(drop=True)
            tipo = "tabla_rotada"
            # Después de transponer la primera fila vuelve a ser el header;
            # re-aplicar detección de header sobre el df transpuesto.
            new_first = df.iloc[0].tolist()
            n_str_new = sum(isinstance(v, str) and str(v).strip() != "" for v in new_first)
            if n_str_new >= len(new_first) * 0.5:
                df.columns = [
                    str(v).strip() if (isinstance(v, str) and str(v).strip()) else f"col{j}"
                    for j, v in enumerate(new_first)
                ]
                df = df.iloc[1:].reset_index(drop=True)

        # ── Paso 3: normalizar tabla cruzada → formato largo ──────────────
        # Una tabla cruzada tiene la primera columna como nombres de métricas
        # y el resto como columnas de valores categóricos.
        # Se convierte con melt para producir filas (Métrica, Header, Valor).
        if self._is_cross_table(df):
            df   = self._normalize_cross_table(df)
            tipo = "tabla_cruzada"

        return TableRegion(
            id          = region_id,
            tipo        = tipo,
            orientacion = "ambiguous",
            fila_inicio = r0 + 1,
            fila_fin    = r1 + 1,
            col_inicio  = c0 + 1,
            col_fin     = c1 + 1,
            fila_header = None,
            col_manager = None,
            col_metrica = None,
            col_headers = {},
            titulo      = None,
            data        = df,
        )

    def _fila_con_mas_fechas(
        self, r0: int, r1: int, c0: int, c1: int,
    ) -> tuple[int, int]:
        """(fila_base0, n_fechas) de la fila con más datetimes/fecha-strings en el rango.

        Detecta headers multinivel: si la fila anterior al mejor candidato tiene
        al menos el 30 % de las fechas de la fila best, se asume que es el nivel
        superior del header (ej. "Q1 Q2 Q3" encima de "ene feb mar abr…") y se
        retrocede un nivel.  El umbral de 0.30 es conservador para no afectar
        hojas donde la fila anterior sea simplemente un título con pocas fechas.
        """
        sub    = self.sc._mask_datetime[r0 : r1 + 1, c0 : c1 + 1]
        counts = sub.sum(axis=1)
        best   = int(counts.argmax())

        # Detectar header multinivel
        if best > 0 and counts[best] > 0:
            prev = int(counts[best - 1])
            if prev >= counts[best] * 0.30:
                best = best - 1   # retroceder al nivel superior del header

        return r0 + best, int(counts[best])


# ══════════════════════════════════════════════════════════════════════════════
# 6. TableAnalyzer  — orquesta y cachea resultados
# ══════════════════════════════════════════════════════════════════════════════

class TableAnalyzer:
    """
    Orquesta WorkbookLoader → SheetScanner → RegionDetector → TableParser.

    La hoja se escanea UNA sola vez en __init__.
    Todas las operaciones posteriores usan la matrix y masks cacheadas.

    Construcción estándar (desde archivo):
        analyzer = TableAnalyzer("archivo.xlsx", "Hoja1")

    Reutilizando scanner existente (no reabre el archivo):
        ws, merged = WorkbookLoader.load("archivo.xlsx", "Hoja1")
        scanner    = SheetScanner(ws, merged)
        analyzer   = TableAnalyzer.from_scanner(scanner)
    """

    def __init__(
        self,
        archivo: str | Path,
        hoja: str,
        umbral_densidad: int = 1,
        gap_max_externo: int = 2,
        gap_max_interno: int = 1,
    ) -> None:
        ws, merged = WorkbookLoader.load(archivo, hoja)
        self._setup(
            SheetScanner(ws, merged),
            umbral_densidad, gap_max_externo, gap_max_interno,
        )

    @classmethod
    def from_scanner(
        cls,
        scanner: SheetScanner,
        umbral_densidad: int = 2,
        gap_max_externo: int = 2,
        gap_max_interno: int = 1,
    ) -> "TableAnalyzer":
        """
        Construye un TableAnalyzer desde un SheetScanner ya construido.
        Permite analizar el mismo archivo varias veces sin reabrirlo.
        """
        instance = object.__new__(cls)
        instance._setup(scanner, umbral_densidad, gap_max_externo, gap_max_interno)
        return instance

    def _setup(
        self,
        scanner: SheetScanner,
        umbral: int, ge: int, gi: int,
    ) -> None:
        self.scanner  = scanner
        self.detector = RegionDetector(scanner, umbral, ge, gi)
        self.parser   = TableParser(scanner)
        self._tablas: list[TableRegion] | None = None

    # ── API interna ────────────────────────────────────────────────────────

    def todas_las_tablas(self) -> list[TableRegion]:
        """Detecta y parsea todas las sub-tablas. Resultado cacheado."""
        if self._tablas is not None:
            return self._tablas
        regiones = self.detector.detectar()
        tablas: list[TableRegion] = []
        for idx, (r0, r1) in enumerate(regiones, start=1):
            region = self.parser.parse(r0, r1, idx)
            if region is not None:
                tablas.append(region)
        self._tablas = tablas
        return tablas

    def tabla_principal(self) -> TableRegion:
        """
        Selecciona la tabla principal usando un ranking más robusto.

        Prioridad:
        1️⃣ tablas que tengan fechas
        2️⃣ score (filas × fechas)
        3️⃣ tamaño del dataframe
        """
        tablas = self.todas_las_tablas()

        if not tablas:
            # fallback: hoja completa como tabla genérica
            mat = self.scanner._mat
            df  = pd.DataFrame(mat)

            return TableRegion(
                id          = 1,
                tipo        = "tabla_generica",
                orientacion = "ambiguous",
                fila_inicio = 1,
                fila_fin    = self.scanner.nrows,
                col_inicio  = 1,
                col_fin     = self.scanner.ncols,
                fila_header = None,
                col_manager = None,
                col_metrica = None,
                col_headers = {},
                titulo      = "fallback_sheet",
                data        = df,
            )

        def ranking(t):
            return (
                len(t.col_headers),   # prioridad a tablas con fechas
                t.score,              # score actual
                len(t.data)           # tamaño
            )

        return max(tablas, key=ranking)

    def fechas(self) -> list[dict[str, Any]]:
        """
        Fechas únicas de la hoja en orden cronológico.
        Reutiliza _mask_datetime ya cacheada: sin escaneo adicional.
        """
        posiciones = np.argwhere(self.scanner._mask_datetime)
        vistas: set[datetime.datetime] = set()
        result: list[dict[str, Any]]   = []

        for r, c in posiciones:
            v = self.scanner[int(r), int(c)]
            if isinstance(v, datetime.datetime) and v not in vistas:
                vistas.add(v)
                result.append({
                    "datetime": v,
                    "label":    self.scanner.fmt_fecha(v),
                    "row":      int(r) + 1,
                    "col":      int(c) + 1,
                })

        result.sort(key=lambda x: x["datetime"])
        return result


# ══════════════════════════════════════════════════════════════════════════════
# 7. API PÚBLICA  — 100% compatible con v3, v4 y v5
# ══════════════════════════════════════════════════════════════════════════════

def detectar_fechas(ws: Any, merged_map: dict) -> list[dict[str, Any]]:
    """
    Detecta todas las fechas únicas de la hoja, ordenadas cronológicamente.

    Firma compatible con v3 (acepta ws + merged_map).
    Para uso nuevo, prefiere TableAnalyzer.fechas() que reutiliza
    _mask_datetime ya cacheada y no requiere ws ni merged_map.
    """
    vistas: set[datetime.datetime] = set()
    result: list[dict[str, Any]]   = []
    for r in range(1, ws.max_row + 1):
        for c in range(1, ws.max_column + 1):
            v = merged_map.get((r, c), ws.cell(r, c).value)
            if isinstance(v, datetime.datetime) and v not in vistas:
                vistas.add(v)
                result.append({
                    "datetime": v,
                    "label":    SheetScanner.fmt_fecha(v),
                    "row":      r,
                    "col":      c,
                })
    result.sort(key=lambda x: x["datetime"])
    return result


def detectar_todas_las_tablas(archivo: str, hoja: str) -> list[dict[str, Any]]:
    """
    Detecta y parsea TODAS las sub-tablas de la hoja en un solo escaneo.

    Args:
        archivo: Ruta al .xlsx
        hoja   : Nombre de la hoja

    Returns:
        Lista de dicts, uno por sub-tabla:
        {
          "id", "tipo", "orientacion", "score",
          "fila_inicio", "fila_fin", "col_inicio", "col_fin",
          "fila_header", "col_manager", "col_metrica",
          "col_headers", "titulo",
          "data": pd.DataFrame
        }

    Ejemplo:
        tablas = detectar_todas_las_tablas("archivo.xlsx", "Hoja1")
        for t in tablas:
            print(t["id"], t["tipo"], f"score={t['score']:.0f}")
    """
    return [t.as_dict() for t in TableAnalyzer(archivo, hoja).todas_las_tablas()]


def detectar_tabla(archivo: str, hoja: str) -> dict[str, Any]:
    """
    Devuelve la tabla PRINCIPAL de la hoja (mayor score).

    score = n_filas_datos × n_columnas_fecha

    Args:
        archivo: Ruta al .xlsx
        hoja   : Nombre de la hoja

    Returns:
        Dict con claves:
          "id", "tipo", "orientacion", "score",
          "fila_inicio", "fila_fin", "col_inicio", "col_fin",
          "fila_header", "col_manager", "col_metrica",
          "col_headers", "titulo",
          "data" → pd.DataFrame con MultiIndex (Manager, Métrica)

    Ejemplo:
        tabla = detectar_tabla("archivo.xlsx", "Hoja1")
        print(tabla["score"])        # 1620.0 = 45 filas × 36 fechas
        print(tabla["orientacion"])  # "column"
        print(tabla["data"].head())
    """
    return TableAnalyzer(archivo, hoja).tabla_principal().as_dict()


def extraer_columna(tabla: dict[str, Any], fecha: str) -> pd.Series:
    """
    Extrae todos los valores de una columna (fecha/periodo).

    Args:
        tabla : Resultado de detectar_tabla() o elemento de detectar_todas_las_tablas().
        fecha : Etiqueta de columna, ej. 'ene-26', 'TOTAL'.

    Returns:
        pd.Series con MultiIndex (Manager, Métrica) o (Métrica,).

    Raises:
        KeyError si la columna no existe (muestra disponibles).
    """
    df = tabla["data"]
    if fecha not in df.columns:
        raise KeyError(
            f"Columna '{fecha}' no encontrada. Disponibles: {list(df.columns)}"
        )
    return df[fecha]


def extraer_fila(tabla: dict[str, Any], metrica: str) -> pd.DataFrame:
    """
    Extrae todos los valores de una métrica para todos los managers.
    Búsqueda parcial e insensible a mayúsculas.

    Args:
        tabla   : Resultado de detectar_tabla().
        metrica : Nombre de la métrica, ej. 'AUM', 'ROA', 'FN'.

    Returns:
        pd.DataFrame con índice Manager y columnas de fecha.

    Raises:
        KeyError si la métrica no existe (muestra disponibles).
    """
    df    = tabla["data"]
    names = df.index.names or []
    nivel = "Métrica" if "Métrica" in names else (names[-1] if names else None)
    if nivel is None:
        raise ValueError("El DataFrame no tiene índice nombrado.")
    mask = df.index.get_level_values(nivel).str.contains(
        metrica, case=False, na=False
    )
    res = df[mask]
    if res.empty:
        disp = df.index.get_level_values(nivel).unique().tolist()
        raise KeyError(
            f"Métrica '{metrica}' no encontrada. Disponibles: {disp}"
        )
    return res.droplevel(nivel) if "Manager" in names else res


def crear_tabla(tabla: dict[str, Any]) -> pd.DataFrame:
    """
    Convierte la tabla al formato LARGO con columna "Fecha" en orden cronológico.

    Estructura del resultado:
        Manager | Métrica | Fecha   | Valor
        --------|---------|---------|------
        First T | AUM     | ene-24  | 12.0
        First T | AUM     | feb-24  | None

    Args:
        tabla: Resultado de detectar_tabla() o elemento de detectar_todas_las_tablas().

    Returns:
        pd.DataFrame con columnas [Manager (si existe), Métrica, Fecha, Valor].
    """
    df = tabla["data"]
    if df is None or df.empty:
        return pd.DataFrame()

    col_headers = tabla.get("col_headers", {})
    if col_headers:
        cols_ord    = [col_headers[c] for c in sorted(col_headers.keys())]
        cols_fechas = [c for c in cols_ord if c in df.columns]
    else:
        cols_fechas = list(df.columns)

    df_reset = df.reset_index()
    id_vars  = [c for c in df_reset.columns if c not in cols_fechas]

    df_largo = df_reset.melt(
        id_vars=id_vars,
        value_vars=cols_fechas,
        var_name="Fecha",
        value_name="Valor",
    )

    orden_map        = {lbl: i for i, lbl in enumerate(cols_fechas)}
    df_largo["_ord"] = df_largo["Fecha"].map(orden_map)
    df_largo = (
        df_largo
        .sort_values(id_vars + ["_ord"])
        .drop(columns="_ord")
        .reset_index(drop=True)
    )
    return df_largo


def replicar_tabla(
    tabla: dict[str, Any],
    archivo_salida: str,
    hoja_salida: str = "Tabla_Limpia",
    formato: str = "ancho",
) -> None:
    """
    Exporta la tabla a un Excel limpio sin filas vacías ni separaciones.

    Args:
        tabla          : Resultado de detectar_tabla().
        archivo_salida : Ruta del .xlsx de salida.
        hoja_salida    : Nombre de la hoja destino.
        formato        : "ancho" (una col por fecha) | "largo" (col Fecha + Valor).
    """
    from openpyxl.styles import Alignment, Font, PatternFill

    df_export = crear_tabla(tabla) if formato == "largo" else tabla["data"].reset_index()
    if df_export.empty:
        raise ValueError("La tabla detectada está vacía.")

    wb_out = openpyxl.Workbook()
    ws_out = wb_out.active
    ws_out.title = hoja_salida

    hfont  = Font(bold=True, color="FFFFFF")
    hfill  = PatternFill(fill_type="solid", fgColor="2F5496")
    halign = Alignment(horizontal="center")

    for ci, h in enumerate(df_export.columns, 1):
        cell = ws_out.cell(row=1, column=ci, value=h)
        cell.font = hfont; cell.fill = hfill; cell.alignment = halign

    for ri, row in enumerate(df_export.itertuples(index=False), 2):
        for ci, v in enumerate(row, 1):
            ws_out.cell(row=ri, column=ci, value=v)

    for col in ws_out.columns:
        w = max(len(str(c.value)) if c.value is not None else 0 for c in col)
        ws_out.column_dimensions[get_column_letter(col[0].column)].width = min(w + 4, 40)

    wb_out.save(archivo_salida)
    print(f"✅ Exportado ({formato}) → {Path(archivo_salida).resolve()}")


# ── Compatibilidad hacia atrás ─────────────────────────────────────────────

def expandir_merged_cells(ws: Any) -> dict[tuple[int, int], Any]:
    """
    Expande merged cells en {(row, col): valor} base-1.
    Mantenida por compatibilidad con código que use la API de v3/v4/v5.
    En v6, SheetScanner expande los merges directamente en la matrix numpy.
    """
    mm: dict[tuple[int, int], Any] = {}
    for rng in ws.merged_cells.ranges:
        val = ws.cell(rng.min_row, rng.min_col).value
        for r in range(rng.min_row, rng.max_row + 1):
            for c in range(rng.min_col, rng.max_col + 1):
                mm[(r, c)] = val
    return mm


# ══════════════════════════════════════════════════════════════════════════════
# DEMO
# ══════════════════════════════════════════════════════════════════════════════

if __name__ == "__main__":
    import time, warnings
    warnings.filterwarnings("ignore")
    pd.set_option("display.max_columns", 7)
    pd.set_option("display.width", 120)

    ARCHIVO = "PRESUPUESTO_2026.xlsx"
    HOJA    = "Generación EV-2026"

    print("=" * 70)
    print(f"  {ARCHIVO}  /  {HOJA}")
    print("=" * 70)

    # ── Benchmark de construcción ──────────────────────────────────────────
    t0 = time.perf_counter()
    analyzer = TableAnalyzer(ARCHIVO, HOJA)
    t1 = time.perf_counter()
    sc = analyzer.scanner
    print(f"\n⚡ SheetScanner v6: {(t1-t0)*1000:.1f} ms  "
          f"({sc.nrows}×{sc.ncols} = {sc.nrows*sc.ncols:,} celdas)")
    print(f"   Orientación     : {sc.orientation!r}")
    print(f"   Celdas con datos: {sc._mask_meaningful.sum():,} "
          f"({sc._mask_meaningful.mean()*100:.0f}%)")
    print(f"   Datetimes       : {sc._mask_datetime.sum()}")

    # 0. Fechas
    fch = analyzer.fechas()
    print(f"\n📅 {len(fch)} fechas: "
          f"{[f['label'] for f in fch[:3]]} … {[f['label'] for f in fch[-3:]]}")

    # 1. Todas las tablas
    todas = analyzer.todas_las_tablas()
    print(f"\n🗂  {len(todas)} sub-tablas:")
    for t in todas:
        print(f"   [{t.id}] {t.tipo:20s}  score={t.score:>8.0f}  "
              f"filas {t.fila_inicio:3d}→{t.fila_fin:3d}  shape={t.data.shape}"
              + (f"  título={t.titulo!r}" if t.titulo else ""))

    # 2. Tabla principal
    principal = analyzer.tabla_principal()
    df        = principal.data
    print(f"\n🏆 Tabla principal → score={principal.score:.0f}  shape={df.shape}")
    if "Manager" in df.index.names:
        print(f"   Managers : {df.index.get_level_values('Manager').unique().tolist()}")
        print(f"   Métricas : {df.index.get_level_values('Métrica').unique().tolist()}")
    print()
    print(df.head(8).to_string(max_cols=7))

    # Benchmark API pública
    t2 = time.perf_counter()
    tabla = detectar_tabla(ARCHIVO, HOJA)
    t3 = time.perf_counter()
    print(f"\n⚡ detectar_tabla() API: {(t3-t2)*1000:.1f} ms")

    # from_scanner
    t4 = time.perf_counter()
    ws_r, mr = WorkbookLoader.load(ARCHIVO, HOJA)
    sc2  = SheetScanner(ws_r, mr)
    a2   = TableAnalyzer.from_scanner(sc2)
    _ = a2.tabla_principal()
    t5 = time.perf_counter()
    print(f"⚡ from_scanner:         {(t5-t4)*1000:.1f} ms  (scanner reutilizable)")

    # extraer_columna
    primera = list(tabla["col_headers"].values())[0]
    print(f"\n── extraer_columna(tabla, '{primera}') ──")
    print(extraer_columna(tabla, primera).dropna().to_string())

    # extraer_fila
    print(f"\n── extraer_fila(tabla, 'AUM') ──")
    print(extraer_fila(tabla, "AUM").to_string(max_cols=7))

    # crear_tabla
    df_l = crear_tabla(tabla)
    print(f"\n── crear_tabla → shape={df_l.shape} ──")
    print(df_l.dropna(subset=["Valor"]).head(10).to_string(index=False))

    # Exportar
    replicar_tabla(tabla, "tabla_limpia_ancho.xlsx", formato="ancho")
    replicar_tabla(tabla, "tabla_limpia_largo.xlsx",  formato="largo")