# Excel Analyzer

Library for detecting and extracting tables from messy Excel files.

Features:

- Detect tables automatically
- Handle merged cells
- Query metrics from Excel
- Build analytical tables